# Kotlin Warehouse - minimal skeleton

Open this project in Android Studio and implement the code from the earlier conversation. This is a skeleton with gradle files and a MainActivity placeholder.
